s1 = "a simple string"
s2 = "a string to encode"

def s2.cipher
  "xxxxxxxxx"
end

puts s1.to_s
puts s2.cipher
