
def use_student_proc(name, surname, number)
  student_proc = Proc.new { return "Student: #{name} #{surname}" }
  student_proc.call
  puts "and number: #{number}"
end

def use_student_lambda(name, surname, number)
  student_lambda = lambda { return "Student: #{name} #{surname}" }
  puts student_lambda.call
  puts "and number: #{number}"
end

