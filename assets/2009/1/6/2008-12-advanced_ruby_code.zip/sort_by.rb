#blatantly stolen from Hal Fulton's "Ruby Way" (listing 11.9)

class Person
  attr_reader :name, :age, :height
  def initialize(name, age, height)
     @name, @age, @height = name, age, height
  end
  def inspect
     "#@name #@age #@height"
  end
end

class Array
  def sort_by(sym)    # Our own version of sort_by
     self.sort {|x,y| x.send(sym) <=> y.send(sym) }
  end
end

people  = []
people  << Person.new("Hansel", 35, 69)
people  << Person.new("Gretel", 32, 64)
people  << Person.new("Ted", 36, 68)
people  << Person.new("Alice", 33, 63)

p1 = people.sort_by(:name)
p2 = people.sort_by(:age)
p3 = people.sort_by(:height)

p p1    # [Alice 33 63, Gretel 32 64, Hansel 35 69, Ted 36 68]
p p2    # [Gretel 32 64, Alice 33 63, Hansel 35 69, Ted 36 68]
p p3    # [Alice 33 63, Gretel 32 64, Ted 36 68, Hansel 35 69]


